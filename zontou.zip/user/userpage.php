<?php
$u=1;
include "../lib/up.php";
?>
  
<div class="container ">
	
<?php


	if(@$_SESSION['id']!="")
	{

		
		echo "<h1>This is the UserPage</h1>";
	
	
	
	
	}
	
	?>
	
	
	
</div>

</body>
</html>
