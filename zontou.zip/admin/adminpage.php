<?php
$u=2;
include ("../lib/up.php");



	if(@$_SESSION['id']!="")
	{
		
		echo "
		<div class='container'>
		<h1>Administration Page<h1>
		</div>
		
		";
	}
	?>
</body>
</html>
